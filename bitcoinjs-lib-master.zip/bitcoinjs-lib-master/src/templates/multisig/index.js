module.exports = {
  input: require('./input'),
  output: require('./output')
}
